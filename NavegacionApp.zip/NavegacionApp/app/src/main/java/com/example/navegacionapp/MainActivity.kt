package com.example.navegacionapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.example.navegacionapp.modelo.EstudianteEntity
import com.example.navegacionapp.modelo.NavegacionAppApplication
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContentView(R.layout.activity_main)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        val navController = navHostFragment.navController

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)


        setupActionBarWithNavController(navController)

        crearEstudiante("juan", "Ingenieria")
    }

    override fun onSupportNavigateUp(): Boolean {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.navHostFragment) as NavHostFragment
        val navController = navHostFragment.navController
        return navController.navigateUp() || super.onSupportNavigateUp()
    }


    fun crearEstudiante(nombre: String = "", carrera: String = "") {
        lifecycleScope.launch {
            NavegacionAppApplication.database.estudianteDao().insertar(EstudianteEntity(nombre = nombre, carrera = carrera))
        }
    }
}
