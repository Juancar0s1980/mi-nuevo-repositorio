package com.example.navegacionapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.example.navegacionapp.modelo.NavegacionAppApplication
import com.example.navegacionapp.modelo.EstudianteEntity
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import android.widget.EditText
import android.widget.Button

class EditarEstudianteFragment : Fragment() {

    private val args: EditarEstudianteFragmentArgs by navArgs()  // Obtén el argumento

    private lateinit var editTextNombre: EditText
    private lateinit var editTextCarrera: EditText
    private lateinit var btnGuardar: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_editar_estudiante, container, false)

        // Encuentra las vistas
        editTextNombre = root.findViewById(R.id.editTextNombre)
        editTextCarrera = root.findViewById(R.id.editTextCarrera)
        btnGuardar = root.findViewById(R.id.btnGuardar)

        // Obtener el estudiante a partir del id
        obtenerEstudiantePorId(args.estudianteId)

        // Configurar el botón de guardar
        btnGuardar.setOnClickListener {
            guardarCambios()
        }

        return root
    }

    private fun obtenerEstudiantePorId(id: Int) {
        lifecycleScope.launch {
            val estudiante = NavegacionAppApplication.database.estudianteDao().obtenerPorId(id)
            estudiante?.let {
                editTextNombre.setText(it.nombre)
                editTextCarrera.setText(it.carrera)
            }
        }
    }

    private fun guardarCambios() {
        val nombre = editTextNombre.text.toString()
        val carrera = editTextCarrera.text.toString()

        if (nombre.isNotEmpty() && carrera.isNotEmpty()) {
            val estudianteEditado = EstudianteEntity(id = args.estudianteId, nombre = nombre, carrera = carrera)
            lifecycleScope.launch {
                NavegacionAppApplication.database.estudianteDao().actualizar(estudianteEditado)
                // Aquí podrías volver al fragmento anterior o hacer alguna otra acción
            }
        }
    }
}
