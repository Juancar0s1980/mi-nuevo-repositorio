package com.example.navegacionapp

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.navegacionapp.modelo.NavegacionAppApplication
import kotlinx.coroutines.launch
import androidx.lifecycle.LiveData
import androidx.lifecycle.observe
import androidx.lifecycle.asLiveData
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.navegacionapp.modelo.EstudianteEntity


class EstudiantesFragment : Fragment() {

    private val args: EstudiantesFragmentArgs by navArgs()

    private lateinit var viewModel: EstudiantesViewModel
    private lateinit var recyclerView: RecyclerView
    private lateinit var estudiantesAdapter: EstudiantesAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_estudiantes, container, false)

        // Configurar el RecyclerView
        recyclerView = root.findViewById(R.id.recyclerViewEstudiantes)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Pasamos las funciones onEditarClick y onEliminarClick al adaptador
        estudiantesAdapter = EstudiantesAdapter(
            onEditarClick = { estudiante -> editarEstudiante(estudiante) },
            onEliminarClick = { estudiante -> eliminarEstudiante(estudiante) }
        )
        recyclerView.adapter = estudiantesAdapter

        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Log.d("EstudiantesFragment", "Fragment creado")

        val estudianteId = args.estudianteId
        if (estudianteId != -1) {
            obtenerEstudiantePorId(estudianteId)
        } else {
            obtenerEstudiantes()
        }
    }

    private fun obtenerEstudiantes() {
        // Usamos el método asLiveData para convertir el Flow en LiveData
        val estudiantesLiveData = NavegacionAppApplication.database
            .estudianteDao()
            .obtenerTodos()
            .asLiveData()

        // Observamos el LiveData utilizando viewLifecycleOwner para el ciclo de vida del Fragment
        estudiantesLiveData.observe(viewLifecycleOwner) { estudiantes ->
            Log.d("EstudiantesFragment", "Estudiantes obtenidos: ${estudiantes.size}")
            estudiantesAdapter.submitList(estudiantes)
        }
    }

    private fun obtenerEstudiantePorId(id: Int) {
        lifecycleScope.launch {
            val estudiante = NavegacionAppApplication.database.estudianteDao().obtenerPorId(id)
            estudiante?.let {
                estudiantesAdapter.submitList(listOf(it))
            }
        }
    }

    private fun editarEstudiante(estudiante: EstudianteEntity) {
        val action = EstudiantesFragmentDirections
            .actionEstudiantesFragmentToEditarEstudianteFragment(estudiante.id)
        findNavController().navigate(action)
    }


    private fun eliminarEstudiante(estudiante: EstudianteEntity) {
        lifecycleScope.launch {
            NavegacionAppApplication.database.estudianteDao().eliminar(estudiante)

            // Después de eliminar, actualizamos la lista de estudiantes
            obtenerEstudiantes()
        }
    }
}