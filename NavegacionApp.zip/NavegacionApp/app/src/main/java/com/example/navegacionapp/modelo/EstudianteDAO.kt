package com.example.navegacionapp.modelo

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao

interface EstudianteDAO {
    @Insert
    suspend fun insertar(estudiante: EstudianteEntity)

    @Query("SELECT * FROM estudiantes")
    fun obtenerTodos(): Flow<List<EstudianteEntity>>

    @Update
    suspend fun actualizar(estudiante: EstudianteEntity)

    @Delete
    suspend fun eliminar(estudiante: EstudianteEntity)

    // Obtener un estudiante por ID
    @Query("SELECT * FROM estudiantes WHERE id = :id LIMIT 1")
    suspend fun obtenerPorId(id: Int): EstudianteEntity?
}