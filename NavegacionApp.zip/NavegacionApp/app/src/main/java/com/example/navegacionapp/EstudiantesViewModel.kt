package com.example.navegacionapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.navegacionapp.modelo.EstudianteEntity
import com.example.navegacionapp.modelo.AppDatabase
import androidx.lifecycle.asLiveData

class EstudiantesViewModel(application: Application) : AndroidViewModel(application) {

    private val estudianteDao = AppDatabase.getDatabase(application).estudianteDao()

    // Convertir el Flow a LiveData
    val listaEstudiantes: LiveData<List<EstudianteEntity>> =
        estudianteDao.obtenerTodos().asLiveData()
}
