package com.example.navegacionapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.navegacionapp.modelo.EstudianteEntity

// Crear un DiffUtil para comparar los elementos en la lista
object EstudianteDiffCallback : DiffUtil.ItemCallback<EstudianteEntity>() {
    override fun areItemsTheSame(oldItem: EstudianteEntity, newItem: EstudianteEntity): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: EstudianteEntity, newItem: EstudianteEntity): Boolean {
        return oldItem == newItem
    }
}

// Adapter para mostrar los estudiantes en el RecyclerView
class EstudiantesAdapter(
    private val onEditarClick: (EstudianteEntity) -> Unit, // Acción cuando se hace clic en editar
    private val onEliminarClick: (EstudianteEntity) -> Unit  // Acción cuando se hace clic en eliminar
) : ListAdapter<EstudianteEntity, EstudiantesAdapter.EstudianteViewHolder>(EstudianteDiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EstudianteViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_estudiante, parent, false)
        return EstudianteViewHolder(view)
    }

    override fun onBindViewHolder(holder: EstudianteViewHolder, position: Int) {
        val estudiante = getItem(position) // Usa getItem para obtener el estudiante en esa posición
        holder.bind(estudiante)
    }

    inner class EstudianteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nombreTextView: TextView = itemView.findViewById(R.id.nombreEstudiante)
        private val carreraTextView: TextView = itemView.findViewById(R.id.carreraEstudiante)
        private val btnEditar: Button = itemView.findViewById(R.id.btnEditar)
        private val btnEliminar: Button = itemView.findViewById(R.id.btnEliminar)

        fun bind(estudiante: EstudianteEntity) {
            nombreTextView.text = estudiante.nombre
            carreraTextView.text = estudiante.carrera

            // Clic en el botón Editar
            btnEditar.setOnClickListener {
                onEditarClick(estudiante) // Llama a la función pasada como parámetro
            }

            // Clic en el botón Eliminar
            btnEliminar.setOnClickListener {
                onEliminarClick(estudiante) // Llama a la función pasada como parámetro
            }
        }
    }

    // Callback para comparar objetos EstudianteEntity en la lista
    object EstudianteDiffCallback : DiffUtil.ItemCallback<EstudianteEntity>() {
        override fun areItemsTheSame(oldItem: EstudianteEntity, newItem: EstudianteEntity): Boolean {
            return oldItem.id == newItem.id // Compara los ID para saber si son el mismo elemento
        }

        override fun areContentsTheSame(oldItem: EstudianteEntity, newItem: EstudianteEntity): Boolean {
            return oldItem == newItem // Compara el contenido completo
        }
    }
}