// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.navigation.safeargs) apply false
}

buildscript {
    dependencies {
        // Aquí asegúrate que el AGP esté a la versión correcta
        classpath("com.android.tools.build:gradle:8.9.0")  // Usa 8.9.0 aquí
    }
}