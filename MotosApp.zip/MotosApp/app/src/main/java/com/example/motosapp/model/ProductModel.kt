package com.example.motosapp.model

 data class ProductModel (val nombre:String, val precio:Double)