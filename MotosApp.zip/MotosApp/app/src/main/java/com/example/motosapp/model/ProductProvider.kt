package com.example.motosapp.model

class ProductProvider {
    companion object {
        fun eleatorio(): ProductModel {
            val position = (0..2).random()
            return productList[position]
        }

        val productList = listOf<ProductModel>(
            ProductModel(
                nombre = "MT 09",
                precio = 61.000000
            ),
            ProductModel(
                nombre = "Kawasaki\n" +
                        "NINJA 500",
                precio = 38.490000
            ),
            ProductModel(
                nombre = "BMW S 1000 RR",
                precio = 139.990000
            )
        )
    }
}
