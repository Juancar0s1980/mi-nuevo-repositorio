package com.example.motosapp.view

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import com.example.motosapp.databinding.ActivityMainBinding
import com.example.motosapp.viewModel.ProductViewModel

class MainActivity : AppCompatActivity() {

    //Declaracion del binding: es el layout xml en kotlin
    private lateinit var binding: ActivityMainBinding
    // Intancia del viewmodel
    private val productViewModel : ProductViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        //setContentView(R.layout.activity_main)
        setContentView(binding.root)
// Observar las variables en timpo real con LiveData
        productViewModel._productModel.observe(this, Observer{
            binding.tvNombre.text =it.nombre
            binding.tvPrecio.text =it.precio.toString()
        })

        // Evento de boton para generar una cita aletoria
        binding.viewContainer.setOnClickListener {
            productViewModel.motoAletorio()

        }

    }
}