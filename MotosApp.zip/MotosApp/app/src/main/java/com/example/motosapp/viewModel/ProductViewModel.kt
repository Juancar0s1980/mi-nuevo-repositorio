package com.example.motosapp.viewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.motosapp.model.ProductModel
import com.example.motosapp.model.ProductProvider

class ProductViewModel : ViewModel() {
    val _productModel = MutableLiveData<ProductModel>()

    fun motoAletorio(){
        val productProvider = ProductProvider.eleatorio()
        _productModel.postValue(productProvider)
    }
}